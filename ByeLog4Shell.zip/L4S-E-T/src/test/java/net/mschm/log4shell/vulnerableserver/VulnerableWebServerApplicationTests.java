package net.mschm.log4shell.vulnerableserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VulnerableWebServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
